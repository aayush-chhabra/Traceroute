
var http = require('http');
var traceroute = require('traceroute');



http.createServer(function (req, res) {
  var body = "";
  var clientIP = getClientAddress(req);
  traceroute.trace(clientIP, function(err,hops){
  	if (!err) console.log(hops);
  });
  //console.log(clientIP);
  req.on('data', function (chunk) {
    body += chunk;
  });
  req.on('end', function () {
    console.log('JSON Object: ' + body);
    res.writeHead(200);
    res.end("I got the Data!!");
  });
}).listen(8080);


getClientAddress = function (req) {
        return (req.headers['x-forwarded-for'] || '').split(',')[0] 
        || req.connection.remoteAddress;
};